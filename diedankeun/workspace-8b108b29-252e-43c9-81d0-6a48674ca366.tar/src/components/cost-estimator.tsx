'use client'

import { useState, useMemo } from 'react'
import { motion } from 'framer-motion'
import { MapPin, Calculator, Car, Info } from 'lucide-react'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Input } from '@/components/ui/input'

interface AreaOption {
  value: string
  label: string
  km: number
}

const areaOptions: AreaOption[] = [
  { value: 'gumuruh', label: 'Gumuruh & sekitar (0-5 km)', km: 0 },
  { value: 'buahbatu', label: 'Buah Batu & sekitar (6-10 km)', km: 5 },
  { value: 'kiaracondong', label: 'Kiaracondong & sekitar (11-15 km)', km: 10 },
  { value: 'cimahi', label: 'Cimahi & sekitar (16-20 km)', km: 15 },
  { value: 'custom', label: 'Lainnya (input manual)', km: 0 },
]

const BASE_FEE = 50000
const PER_KM_FEE = 5000

const exampleEstimates = [
  { distance: '0-5 km', cost: 'Rp50.000' },
  { distance: '6-10 km', cost: 'Rp75.000' },
  { distance: '11-15 km', cost: 'Rp100.000' },
  { distance: '16-20 km', cost: 'Rp125.000' },
]

function formatRupiah(amount: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount)
}

export default function CostEstimator() {
  const [selectedArea, setSelectedArea] = useState<string>('')
  const [manualKm, setManualKm] = useState<string>('')

  const isCustom = selectedArea === 'custom'

  const estimatedCost = useMemo(() => {
    if (!selectedArea) return 0

    if (isCustom) {
      const km = parseFloat(manualKm)
      if (!isNaN(km) && km >= 0) {
        return BASE_FEE + Math.round(km) * PER_KM_FEE
      }
      return 0
    }

    const area = areaOptions.find((a) => a.value === selectedArea)
    if (area) {
      return BASE_FEE + Math.round(area.km) * PER_KM_FEE
    }
    return 0
  }, [selectedArea, manualKm, isCustom])

  return (
    <section id="estimasi" className="py-20 px-4 md:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <h2 className="font-heading text-4xl md:text-5xl font-bold text-white mb-4">
            Estimasi Biaya{' '}
            <span className="gold-shimmer">Panggilan</span>
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto mb-3">
            Hitung estimasi biaya panggilan teknisi ke rumah Anda
          </p>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent mx-auto" />
        </motion.div>

        {/* Base Location */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="flex items-center gap-2 justify-center mb-10"
        >
          <MapPin className="size-4 text-[#D4AF37]" />
          <span className="text-sm text-gray-400">
            Titik Awal: <span className="text-gray-300">Kelurahan Gumuruh, Kecamatan Batununggal, Bandung</span>
          </span>
        </motion.div>

        {/* Calculator Card */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.6 }}
          className="glass-strong rounded-2xl p-6 md:p-8 gradient-border"
        >
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#D4AF37] to-[#B8960C] flex items-center justify-center text-black">
              <Calculator className="size-5" />
            </div>
            <h3 className="font-heading text-xl font-semibold text-white">
              Kalkulator Biaya
            </h3>
          </div>

          {/* Formula Display */}
          <div className="mb-8 p-4 rounded-xl bg-white/[0.03] border border-white/[0.06]">
            <p className="text-sm text-gray-400 mb-1">Rumus perhitungan:</p>
            <p className="text-[#D4AF37] font-mono text-sm">
              Biaya Panggilan = Rp50.000 + (Jarak × Rp5.000/km)
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {/* Area Select */}
            <div className="space-y-2.5">
              <label className="text-sm font-medium text-gray-300">
                Pilih Area
              </label>
              <Select
                value={selectedArea}
                onValueChange={(value) => {
                  setSelectedArea(value)
                  if (value !== 'custom') {
                    setManualKm('')
                  }
                }}
              >
                <SelectTrigger className="w-full h-11 bg-white/[0.04] border-white/[0.1] text-white hover:border-[#D4AF37]/40 transition-colors">
                  <SelectValue placeholder="Pilih area Bandung..." />
                </SelectTrigger>
                <SelectContent className="bg-[#1a1a1a] border-white/[0.1]">
                  {areaOptions.map((option) => (
                    <SelectItem
                      key={option.value}
                      value={option.value}
                      className="text-gray-300 focus:text-white focus:bg-white/[0.06]"
                    >
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Manual KM Input */}
            <div className="space-y-2.5">
              <label className="text-sm font-medium text-gray-300">
                {isCustom ? 'Masukkan Jarak (km)' : 'Atau Input Manual (km)'}
              </label>
              <div className="relative">
                <Input
                  type="number"
                  min="0"
                  step="1"
                  placeholder={isCustom ? 'Contoh: 12' : 'Input jarak manual...'}
                  value={manualKm}
                  onChange={(e) => {
                    setManualKm(e.target.value)
                    if (e.target.value && selectedArea !== 'custom') {
                      setSelectedArea('custom')
                    }
                  }}
                  className="h-11 bg-white/[0.04] border-white/[0.1] text-white placeholder:text-gray-600 hover:border-[#D4AF37]/40 transition-colors pr-12"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-gray-500 pointer-events-none">
                  km
                </span>
              </div>
            </div>
          </div>

          {/* Result Display */}
          <motion.div
            key={estimatedCost}
            initial={{ scale: 0.97, opacity: 0.7 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.3 }}
            className={`rounded-xl p-6 text-center transition-all duration-500 ${
              estimatedCost > 0
                ? 'bg-gradient-to-br from-[#D4AF37]/10 to-[#B8960C]/5 border border-[#D4AF37]/20 gold-glow'
                : 'bg-white/[0.02] border border-white/[0.06]'
            }`}
          >
            <div className="flex items-center justify-center gap-2 mb-2">
              <Car className="size-5 text-[#D4AF37]" />
              <span className="text-sm text-gray-400">Estimasi Biaya Panggilan</span>
            </div>
            <p
              className={`font-heading text-4xl md:text-5xl font-bold transition-colors duration-300 ${
                estimatedCost > 0 ? 'gold-shimmer' : 'text-gray-600'
              }`}
            >
              {estimatedCost > 0 ? formatRupiah(estimatedCost) : 'Rp0'}
            </p>
            {estimatedCost > 0 && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="text-xs text-gray-500 mt-2"
              >
                *Estimasi berdasarkan jarak yang dipilih
              </motion.p>
            )}
          </motion.div>
        </motion.div>

        {/* Example Estimates Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mt-10 glass rounded-2xl p-6 md:p-8"
        >
          <div className="flex items-center gap-2 mb-6">
            <Info className="size-4 text-[#D4AF37]" />
            <h4 className="font-heading text-base font-semibold text-white">
              Contoh Estimasi Biaya
            </h4>
          </div>

          <div className="overflow-hidden rounded-lg border border-white/[0.06]">
            <table className="w-full">
              <thead>
                <tr className="bg-white/[0.04]">
                  <th className="text-left py-3 px-4 text-sm font-medium text-gray-400">
                    Jarak
                  </th>
                  <th className="text-right py-3 px-4 text-sm font-medium text-gray-400">
                    Estimasi Biaya
                  </th>
                </tr>
              </thead>
              <tbody>
                {exampleEstimates.map((item, idx) => (
                  <tr
                    key={idx}
                    className="border-t border-white/[0.04] hover:bg-white/[0.02] transition-colors"
                  >
                    <td className="py-3 px-4 text-sm text-gray-300">
                      {item.distance}
                    </td>
                    <td className="py-3 px-4 text-sm text-[#D4AF37] font-semibold text-right">
                      {item.cost}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <p className="text-xs text-gray-500 mt-4">
            Harga dapat disesuaikan berdasarkan kondisi lapangan.
          </p>
        </motion.div>
      </div>
    </section>
  )
}
