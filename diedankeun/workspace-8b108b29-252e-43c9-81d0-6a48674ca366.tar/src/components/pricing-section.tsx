'use client'

import { motion } from 'framer-motion'
import { Gamepad2, Wrench, Sparkles, ArrowRight, Check, Star } from 'lucide-react'

const WA_LINK = 'https://wa.me/6285163061987?text=Halo%20Mikayla%20Games%2C%20saya%20tertarik%20dengan%20jasa%20install%20game'

interface PricingCard {
  id: string
  icon: React.ReactNode
  name: string
  price: string
  features: string[]
  popular?: boolean
}

const pricingCards: PricingCard[] = [
  {
    id: 'ps3',
    icon: <Gamepad2 className="size-8" />,
    name: 'PS3 HEN',
    price: 'Rp100.000',
    features: [
      'Install HEN firmware terbaru',
      'Bebas install game sesuka hati',
      'Garansi hasil installasi',
    ],
  },
  {
    id: 'ps4',
    icon: <Gamepad2 className="size-8" />,
    name: 'PS4 HEN',
    price: 'Rp150.000',
    features: [
      'Install HEN firmware terbaru',
      'Akses game library lengkap',
      'Bantuan setup & konfigurasi',
    ],
  },
  {
    id: 'ps5',
    icon: <Sparkles className="size-8" />,
    name: 'PS5 Jailbreak',
    price: 'Rp250.000',
    features: [
      'Jailbreak PS5 firmware compatible',
      'Install game & homebrew',
      'Support & update berkala',
    ],
    popular: true,
  },
  {
    id: 'maintenance',
    icon: <Wrench className="size-8" />,
    name: 'Update & Maintenance',
    price: 'Rp50.000',
    features: [
      'Update firmware & game',
      'Cek & perbaikan sistem',
      'Optimasi performa console',
    ],
  },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15,
    },
  },
}

const cardVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      ease: 'easeOut',
    },
  },
}

export default function PricingSection() {
  return (
    <section id="harga" className="py-20 px-4 md:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <h2 className="font-heading text-4xl md:text-5xl font-bold gold-shimmer mb-4">
            Harga Jasa
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent mx-auto" />
        </motion.div>

        {/* Pricing Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-80px' }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {pricingCards.map((card) => (
            <motion.div
              key={card.id}
              variants={cardVariants}
              className={`relative gradient-border rounded-2xl ${
                card.popular ? 'z-10' : ''
              }`}
            >
              {/* Popular Badge */}
              {card.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 z-20">
                  <div className="flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-gradient-to-r from-[#D4AF37] to-[#F0D060] text-black font-bold text-xs tracking-widest uppercase shadow-lg">
                    <Star className="size-3.5 fill-current" />
                    POPULER
                    <Star className="size-3.5 fill-current" />
                  </div>
                </div>
              )}

              <div
                className={`relative rounded-2xl p-6 h-full flex flex-col ${
                  card.popular
                    ? 'glass-strong gold-glow pulse-gold'
                    : 'glass'
                }`}
              >
                {/* Icon */}
                <div
                  className={`w-14 h-14 rounded-xl flex items-center justify-center mb-5 ${
                    card.popular
                      ? 'bg-gradient-to-br from-[#D4AF37] to-[#B8960C] text-black'
                      : 'bg-white/5 text-[#D4AF37]'
                  }`}
                >
                  {card.icon}
                </div>

                {/* Name */}
                <h3 className="font-heading text-lg font-semibold text-white mb-2">
                  {card.name}
                </h3>

                {/* Price */}
                <p
                  className={`font-heading text-3xl font-bold mb-6 ${
                    card.popular ? 'gold-shimmer' : 'text-[#D4AF37]'
                  }`}
                >
                  Mulai {card.price}
                </p>

                {/* Features */}
                <ul className="space-y-3 mb-8 flex-grow">
                  {card.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2.5">
                      <Check
                        className={`size-4 mt-0.5 shrink-0 ${
                          card.popular
                            ? 'text-[#F0D060]'
                            : 'text-[#D4AF37]/70'
                        }`}
                      />
                      <span className="text-sm text-gray-300 leading-relaxed">
                        {feature}
                      </span>
                    </li>
                  ))}
                </ul>

                {/* CTA Button */}
                <a
                  href={WA_LINK}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-full flex items-center justify-center gap-2 py-3 px-4 rounded-lg font-semibold text-sm transition-all duration-300 group ${
                    card.popular
                      ? 'bg-gradient-to-r from-[#D4AF37] to-[#F0D060] text-black hover:shadow-lg hover:shadow-[#D4AF37]/25'
                      : 'border border-[#D4AF37]/30 text-[#D4AF37] hover:bg-[#D4AF37]/10 hover:border-[#D4AF37]/50'
                  }`}
                >
                  Pesan Sekarang
                  <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1" />
                </a>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Note */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center text-sm text-gray-500 mt-10"
        >
          Harga dapat berubah tergantung kapasitas penyimpanan dan jumlah game.
        </motion.p>
      </div>
    </section>
  )
}
