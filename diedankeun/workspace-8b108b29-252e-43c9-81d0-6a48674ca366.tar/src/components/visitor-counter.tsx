'use client'

import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Eye, Users, TrendingUp } from 'lucide-react'
import { cn } from '@/lib/utils'

export default function VisitorCounter() {
  const [count, setCount] = useState<number>(12458)
  const [prevCount, setPrevCount] = useState<number>(12458)
  const countRef = useRef<number>(12458)

  // Initial fetch + polling interval
  useEffect(() => {
    let mounted = true

    const fetchCount = async () => {
      try {
        const res = await fetch('/api/visitors')
        const data = await res.json()
        if (mounted) {
          setPrevCount(countRef.current)
          countRef.current = data.count
          setCount(data.count)
        }
      } catch {
        if (mounted) {
          const increment = Math.floor(Math.random() * 3) + 1
          setPrevCount(countRef.current)
          countRef.current = countRef.current + increment
          setCount(countRef.current)
        }
      }
    }

    // Initial fetch
    fetchCount()

    // Poll every 5 seconds
    const interval = setInterval(fetchCount, 5000)

    return () => {
      mounted = false
      clearInterval(interval)
    }
  }, [])

  // Format number with thousands separator
  const formatNumber = (num: number): string => {
    return num.toLocaleString('id-ID')
  }

  // Get digit-level change info for animation
  const getChangedDigits = (prev: number, curr: number): Set<number> => {
    const changed = new Set<number>()
    const prevStr = formatNumber(prev)
    const currStr = formatNumber(curr)
    const maxLen = Math.max(prevStr.length, currStr.length)

    for (let i = 0; i < maxLen; i++) {
      const pChar = prevStr[prevStr.length - 1 - i] || ''
      const cChar = currStr[currStr.length - 1 - i] || ''
      if (pChar !== cChar) {
        changed.add(currStr.length - 1 - i)
      }
    }
    return changed
  }

  const changedDigits = getChangedDigits(prevCount, count)
  const formattedCount = formatNumber(count)

  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-3xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className={cn(
            'relative rounded-2xl p-6 sm:p-8 text-center',
            'glass-strong gold-glow overflow-hidden'
          )}
        >
          {/* Decorative corner accents */}
          <div className="absolute top-0 left-0 w-16 h-16 border-t-2 border-l-2 border-gold/40 rounded-tl-2xl" />
          <div className="absolute top-0 right-0 w-16 h-16 border-t-2 border-r-2 border-gold/40 rounded-tr-2xl" />
          <div className="absolute bottom-0 left-0 w-16 h-16 border-b-2 border-l-2 border-gold/40 rounded-bl-2xl" />
          <div className="absolute bottom-0 right-0 w-16 h-16 border-b-2 border-r-2 border-gold/40 rounded-br-2xl" />

          {/* Title */}
          <div className="flex items-center justify-center gap-2 mb-6">
            <Eye className="w-5 h-5 text-gold" />
            <h3 className="text-lg sm:text-xl font-semibold font-heading text-gold">
              Pengunjung Hari Ini
            </h3>
            <TrendingUp className="w-5 h-5 text-emerald-400" />
          </div>

          {/* Large Number Display */}
          <div className="mb-6 py-4">
            <div className="flex items-center justify-center gap-0">
              <AnimatePresence mode="popLayout">
                {formattedCount.split('').map((char, idx) => (
                  <motion.span
                    key={`${idx}-${char}`}
                    layout
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    transition={{
                      duration: 0.3,
                      layout: { duration: 0.25 },
                    }}
                    className={cn(
                      'led-digital text-4xl sm:text-5xl md:text-6xl lg:text-7xl inline-block',
                      char === '.' || char === ','
                        ? 'text-gold/60 mx-0.5'
                        : changedDigits.has(idx)
                          ? 'text-gold-light'
                          : 'text-gold'
                    )}
                  >
                    {char}
                  </motion.span>
                ))}
              </AnimatePresence>
            </div>
          </div>

          {/* Subtitle */}
          <div className="flex items-center justify-center gap-2">
            <Users className="w-4 h-4 text-muted-foreground" />
            <p className="text-sm sm:text-base text-muted-foreground max-w-md">
              Ribuan gamer telah mempercayakan layanan mereka kepada Mikayla Games.
            </p>
          </div>

          {/* Pulse indicator */}
          <div className="absolute top-4 right-4 flex items-center gap-1.5">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
            </span>
            <span className="text-xs text-emerald-400 font-medium">Live</span>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
