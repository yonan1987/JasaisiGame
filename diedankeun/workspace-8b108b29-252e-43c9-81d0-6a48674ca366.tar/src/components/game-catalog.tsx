'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Search, Gamepad2, HardDrive, CheckCircle2, ChevronDown } from 'lucide-react'
import { Game, platformFilters } from '@/lib/game-data'
import { cn } from '@/lib/utils'

const ITEMS_PER_PAGE = 12

type FilterTab = 'Semua' | 'PS3' | 'PS4' | 'PS5'

export default function GameCatalog() {
  const [games, setGames] = useState<Game[]>([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [activeFilter, setActiveFilter] = useState<FilterTab>('Semua')
  const [search, setSearch] = useState('')
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [visibleCount, setVisibleCount] = useState(ITEMS_PER_PAGE)
  const debounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  // Debounce search input (300ms)
  useEffect(() => {
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current)
    }
    debounceTimerRef.current = setTimeout(() => {
      setDebouncedSearch(search)
    }, 300)

    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current)
      }
    }
  }, [search])

  // Fetch games from API
  const fetchGames = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (activeFilter !== 'Semua') {
        params.set('platform', activeFilter)
      }
      if (debouncedSearch) {
        params.set('search', debouncedSearch)
      }
      const query = params.toString()
      const url = `/api/games${query ? `?${query}` : ''}`
      const res = await fetch(url)
      const data = await res.json()
      setGames(data.games)
      setTotal(data.total)
    } catch {
      setGames([])
      setTotal(0)
    } finally {
      setLoading(false)
    }
  }, [activeFilter, debouncedSearch])

  useEffect(() => {
    fetchGames()
  }, [fetchGames])

  // Reset visible count when filters change
  useEffect(() => {
    setVisibleCount(ITEMS_PER_PAGE)
  }, [activeFilter, debouncedSearch])

  const visibleGames = games.slice(0, visibleCount)
  const hasMore = visibleCount < games.length

  const filterTabs: FilterTab[] = ['Semua', ...platformFilters]

  return (
    <section id="katalog" className="py-16 px-4 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-heading gold-shimmer mb-4">
            Katalog Game
          </h2>
          <p className="text-muted-foreground text-base sm:text-lg max-w-2xl mx-auto">
            Temukan koleksi game PlayStation terlengkap di Mikayla Games
          </p>
        </motion.div>

        {/* Filter Tabs & Search */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="flex flex-col sm:flex-row gap-4 mb-8"
        >
          {/* Filter Tabs */}
          <div className="flex gap-2 flex-wrap">
            {filterTabs.map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveFilter(tab)}
                className={cn(
                  'px-5 py-2.5 rounded-lg text-sm font-semibold transition-all duration-300 border',
                  activeFilter === tab
                    ? 'bg-gradient-to-r from-gold-dark via-gold to-gold-light text-black border-gold gold-glow'
                    : 'glass text-muted-foreground hover:text-gold hover:border-gold/40'
                )}
              >
                {tab === 'Semua' && <Gamepad2 className="inline w-4 h-4 mr-1.5 -mt-0.5" />}
                {tab}
              </button>
            ))}
          </div>

          {/* Search Input */}
          <div className="relative sm:ml-auto sm:min-w-[280px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Cari Judul Game..."
              className={cn(
                'w-full pl-10 pr-4 py-2.5 rounded-lg text-sm',
                'glass text-foreground placeholder:text-muted-foreground',
                'focus:outline-none focus:border-gold/60 focus:ring-2 focus:ring-gold/20',
                'transition-all duration-300'
              )}
            />
          </div>
        </motion.div>

        {/* Total Count */}
        <div className="mb-6">
          <p className="text-sm text-muted-foreground">
            Menampilkan{' '}
            <span className="text-gold font-semibold">{visibleGames.length}</span>{' '}
            game dari{' '}
            <span className="text-gold font-semibold">{total}</span>{' '}
            game
          </p>
        </div>

        {/* Game Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {loading ? (
            // Skeleton Loading
            Array.from({ length: 8 }).map((_, i) => (
              <div key={`skeleton-${i}`} className="rounded-xl overflow-hidden glass-strong">
                <Skeleton className="w-full aspect-[3/4] rounded-none" />
                <div className="p-3 space-y-2">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-3 w-1/2" />
                  <Skeleton className="h-3 w-1/3" />
                </div>
              </div>
            ))
          ) : (
            <AnimatePresence mode="popLayout">
              {visibleGames.map((game, index) => (
                <GameCard key={game.id} game={game} index={index} />
              ))}
            </AnimatePresence>
          )}
        </div>

        {/* Empty State */}
        {!loading && games.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-16"
          >
            <Gamepad2 className="w-16 h-16 mx-auto text-muted-foreground/50 mb-4" />
            <p className="text-muted-foreground text-lg">
              Game tidak ditemukan. Coba kata kunci lain.
            </p>
          </motion.div>
        )}

        {/* Load More Button */}
        {!loading && hasMore && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex justify-center mt-10"
          >
            <button
              onClick={() => setVisibleCount((prev) => prev + ITEMS_PER_PAGE)}
              className={cn(
                'px-8 py-3 rounded-lg text-sm font-semibold',
                'glass hover:glass-strong transition-all duration-300',
                'text-gold hover:text-gold-light',
                'border border-gold/20 hover:border-gold/40',
                'hover:gold-glow',
                'flex items-center gap-2'
              )}
            >
              Lihat Lebih Banyak
              <ChevronDown className="w-4 h-4" />
            </button>
          </motion.div>
        )}
      </div>
    </section>
  )
}

/* ─── Game Card Component ─── */

function GameCard({ game, index }: { game: Game; index: number }) {
  const [imgError, setImgError] = useState(false)

  return (
    <motion.div
      layout
      layoutId={`game-${game.id}`}
      initial={{ opacity: 0, y: 30, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -20, scale: 0.95 }}
      transition={{
        duration: 0.4,
        delay: index * 0.05,
        layout: { duration: 0.3 },
      }}
      className="group rounded-xl overflow-hidden glass-strong hover:gold-glow transition-all duration-500 flex flex-col"
    >
      {/* Cover Image */}
      <div className="relative w-full aspect-[3/4] overflow-hidden bg-black/40">
        {!imgError ? (
          <img
            src={game.cover}
            alt={game.name}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
            onError={() => setImgError(true)}
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-gold/10 to-transparent">
            <Gamepad2 className="w-12 h-12 text-gold/40" />
          </div>
        )}
        {/* Platform Badge Overlay */}
        <div className="absolute top-2 left-2">
          <span
            className={cn(
              'inline-flex items-center px-2.5 py-1 rounded-md text-xs font-bold',
              'bg-gradient-to-r from-gold-dark via-gold to-gold-light text-black',
              'shadow-lg'
            )}
          >
            {game.platform}
          </span>
        </div>
      </div>

      {/* Card Content */}
      <div className="p-3 sm:p-4 flex flex-col flex-1 gap-2">
        {/* Game Name */}
        <h3 className="text-white font-bold text-sm sm:text-base leading-tight line-clamp-2 group-hover:text-gold transition-colors duration-300">
          {game.name}
        </h3>

        {/* Genre */}
        <p className="text-muted-foreground text-xs sm:text-sm line-clamp-1">
          {game.genre}
        </p>

        {/* File Size */}
        <div className="flex items-center gap-1.5 text-muted-foreground text-xs">
          <HardDrive className="w-3.5 h-3.5 text-gold/60" />
          <span>{game.fileSize}</span>
        </div>

        {/* Status */}
        <div className="flex items-center gap-1.5 mt-auto">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
          </span>
          <span className="text-emerald-400 text-xs font-medium">{game.status}</span>
        </div>

        {/* Detail Button */}
        <button
          className={cn(
            'mt-2 w-full py-2 rounded-lg text-xs sm:text-sm font-semibold',
            'glass hover:glass-strong transition-all duration-300',
            'text-gold hover:text-gold-light',
            'border border-gold/15 hover:border-gold/40',
            'group-hover:gold-glow'
          )}
        >
          <CheckCircle2 className="inline w-3.5 h-3.5 mr-1 -mt-0.5" />
          Lihat Detail
        </button>
      </div>
    </motion.div>
  )
}

/* ─── Skeleton Component (local) ─── */

function Skeleton({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        'bg-white/5 animate-pulse rounded-md',
        className
      )}
    />
  )
}
