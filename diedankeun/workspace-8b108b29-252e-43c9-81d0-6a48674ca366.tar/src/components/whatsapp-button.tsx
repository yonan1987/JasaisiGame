'use client'

import { motion } from 'framer-motion'
import { MessageCircle } from 'lucide-react'
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip'

const WHATSAPP_URL =
  'https://wa.me/6285163061987?text=Halo%20Mikayla%20Games%2C%20saya%20ingin%20bertanya'

export default function WhatsAppButton() {
  return (
    <motion.div
      className="fixed bottom-6 right-6 z-50"
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{
        type: 'spring',
        stiffness: 260,
        damping: 20,
        delay: 1,
      }}
    >
      <Tooltip>
        <TooltipTrigger asChild>
          <a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Chat WhatsApp Sekarang"
            className="group relative flex items-center justify-center w-14 h-14 rounded-full bg-green-500 text-white shadow-lg hover:bg-green-600 hover:scale-110 transition-all duration-300 pulse-green"
          >
            <MessageCircle className="w-7 h-7" />
            {/* Pulsing ring effect */}
            <span className="absolute inset-0 rounded-full bg-green-500 opacity-40 animate-ping" />
          </a>
        </TooltipTrigger>
        <TooltipContent
          side="left"
          className="bg-white/95 text-gray-900 font-medium shadow-xl border-0"
          sideOffset={10}
        >
          Chat WhatsApp Sekarang
        </TooltipContent>
      </Tooltip>
    </motion.div>
  )
}
