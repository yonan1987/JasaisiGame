'use client';

import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Image from 'next/image';

export default function LoadingScreen() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2500);

    return () => clearTimeout(timer);
  }, []);

  return (
    <AnimatePresence>
      {isLoading && (
        <motion.div
          className="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-black"
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6, ease: 'easeInOut' }}
        >
          {/* Subtle radial gold glow behind logo */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-[400px] h-[400px] rounded-full bg-[radial-gradient(circle,rgba(212,175,55,0.08)_0%,transparent_70%)]" />
          </div>

          {/* Logo with reveal animation */}
          <motion.div
            className="relative gold-glow rounded-2xl mb-6"
            initial={{ scale: 0.8, opacity: 0, filter: 'blur(10px)' }}
            animate={{ scale: 1, opacity: 1, filter: 'blur(0px)' }}
            transition={{
              duration: 0.8,
              ease: [0.16, 1, 0.3, 1],
              filter: { duration: 0.6 },
            }}
          >
            <Image
              src="/logo-mikayla.png"
              alt="MIKAYLA GAMES Logo"
              width={120}
              height={120}
              priority
              className="object-contain"
            />
          </motion.div>

          {/* Brand name with gold shimmer */}
          <motion.h1
            className="gold-shimmer text-3xl sm:text-4xl font-extrabold tracking-widest mb-10"
            style={{ fontFamily: "'Montserrat', sans-serif" }}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4, ease: 'easeOut' }}
          >
            MIKAYLA GAMES
          </motion.h1>

          {/* Gold loading bar */}
          <motion.div
            className="w-48 h-[2px] rounded-full overflow-hidden bg-white/5"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.8 }}
          >
            <motion.div
              className="h-full rounded-full"
              style={{
                background:
                  'linear-gradient(90deg, #B8960C, #D4AF37, #F0D060, #D4AF37, #B8960C)',
              }}
              initial={{ width: '0%' }}
              animate={{ width: '100%' }}
              transition={{
                duration: 1.5,
                delay: 0.8,
                ease: [0.25, 0.1, 0.25, 1],
              }}
            />
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
