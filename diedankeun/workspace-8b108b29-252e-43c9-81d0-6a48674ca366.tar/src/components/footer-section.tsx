'use client'

import {
  Instagram,
  Facebook,
  Youtube,
  MapPin,
  Phone,
  Mail,
  MessageCircle,
  ExternalLink,
} from 'lucide-react'

const MAPS_EMBED_URL =
  'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3960.8!2d107.6191!3d-6.9175!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2sGumuruh%2C+Batununggal%2C+Bandung!5e0!3m2!1sid!2sid!4v1'

const MAPS_LINK =
  'https://www.google.com/maps/search/Gumuruh+Batununggal+Bandung'

const socialLinks = [
  { icon: Instagram, href: '#', label: 'Instagram' },
  { icon: Facebook, href: '#', label: 'Facebook' },
  { icon: Youtube, href: '#', label: 'YouTube' },
]

export default function FooterSection() {
  return (
    <footer className="relative">
      {/* Top gold gradient line */}
      <div className="h-[2px] bg-gradient-to-r from-transparent via-gold to-transparent" />

      {/* Main footer content */}
      <div className="bg-[#050505] pt-16 pb-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          {/* Three columns */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10 md:gap-8 mb-12">
            {/* Column 1: Logo + About */}
            <div className="flex flex-col items-center md:items-start text-center md:text-left">
              <div className="mb-4">
                <img
                  src="/logo-mikayla.png"
                  alt="Mikayla Games Logo"
                  className="h-16 w-auto object-contain"
                />
              </div>
              <p className="text-gray-400 text-sm leading-relaxed max-w-xs">
                Layanan instalasi game PlayStation terpercaya di Bandung.
                Teknisi berpengalaman, proses cepat, dan harga terjangkau.
              </p>
            </div>

            {/* Column 2: Alamat */}
            <div className="flex flex-col items-center md:items-start text-center md:text-left">
              <h3 className="text-gold font-heading font-semibold text-lg mb-4 flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                Alamat
              </h3>
              <p className="text-gray-400 text-sm leading-relaxed mb-4">
                Jatimulya V, Kelurahan Gumuruh, Kecamatan Batununggal, Kota
                Bandung, Kode Pos 40275
              </p>
              {/* Google Maps Embed */}
              <div className="w-full rounded-lg overflow-hidden border border-gold/15 mb-3">
                <iframe
                  src={MAPS_EMBED_URL}
                  width="100%"
                  height="150"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Lokasi Mikayla Games"
                  className="grayscale-[60%] contrast-125 opacity-80 hover:grayscale-0 hover:opacity-100 transition-all duration-500"
                />
              </div>
              <a
                href={MAPS_LINK}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-gold/80 hover:text-gold text-xs transition-colors duration-300"
              >
                Buka di Google Maps
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            {/* Column 3: Kontak */}
            <div className="flex flex-col items-center md:items-start text-center md:text-left">
              <h3 className="text-gold font-heading font-semibold text-lg mb-4 flex items-center gap-2">
                <Phone className="w-5 h-5" />
                Kontak
              </h3>
              <div className="space-y-3">
                <a
                  href="https://wa.me/6285163061987?text=Halo%20Mikayla%20Games%2C%20saya%20ingin%20bertanya"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 text-gray-400 hover:text-green-400 transition-colors duration-300 text-sm"
                >
                  <MessageCircle className="w-4 h-4 shrink-0" />
                  <span>+62 851-6306-1987</span>
                </a>
                <a
                  href="tel:+6285163061987"
                  className="flex items-center gap-3 text-gray-400 hover:text-gold transition-colors duration-300 text-sm"
                >
                  <Phone className="w-4 h-4 shrink-0" />
                  <span>+62 851-6306-1987</span>
                </a>
                <a
                  href="mailto:info@mikaylagames.com"
                  className="flex items-center gap-3 text-gray-400 hover:text-gold transition-colors duration-300 text-sm"
                >
                  <Mail className="w-4 h-4 shrink-0" />
                  <span>info@mikaylagames.com</span>
                </a>
              </div>
            </div>
          </div>

          {/* Divider */}
          <div className="h-px bg-gradient-to-r from-transparent via-gold/20 to-transparent mb-6" />

          {/* Social media + Copyright */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            {/* Social media icons */}
            <div className="flex items-center gap-4">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={social.label}
                  className="w-10 h-10 rounded-full border border-gold/20 flex items-center justify-center text-gray-400 hover:text-gold hover:border-gold/60 hover:shadow-[0_0_15px_rgba(212,175,55,0.25)] transition-all duration-300"
                >
                  <social.icon className="w-4 h-4" />
                </a>
              ))}
            </div>

            {/* Copyright */}
            <p className="text-gray-500 text-xs">
              &copy; 2026 Mikayla Games. All Rights Reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}
