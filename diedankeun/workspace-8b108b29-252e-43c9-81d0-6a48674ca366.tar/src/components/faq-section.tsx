'use client'

import { motion } from 'framer-motion'
import { HelpCircle } from 'lucide-react'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'

const faqItems = [
  {
    question: 'Apakah aman?',
    answer: 'Ya, proses dilakukan dengan prosedur yang hati-hati oleh teknisi berpengalaman.',
  },
  {
    question: 'Apakah bisa panggilan?',
    answer: 'Bisa, teknisi kami bisa datang ke rumah Anda di area Bandung dan sekitarnya.',
  },
  {
    question: 'Apakah bisa konsultasi dulu?',
    answer: 'Bisa, konsultasi gratis melalui WhatsApp. Kami siap membantu Anda.',
  },
  {
    question: 'Apakah semua game tersedia?',
    answer: 'Sebagian besar game populer tersedia. Hubungi kami untuk memastikan ketersediaan game yang Anda inginkan.',
  },
  {
    question: 'Berapa lama pengerjaan?',
    answer: 'Tergantung kapasitas penyimpanan dan jumlah game yang diinstal. Biasanya 1-3 jam.',
  },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2,
    },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: 'easeOut' },
  },
}

export default function FaqSection() {
  return (
    <section className="relative py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          className="text-center mb-12"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <HelpCircle className="w-6 h-6 text-gold" />
            <h2 className="text-3xl sm:text-4xl font-bold font-heading gold-shimmer">
              Pertanyaan Umum
            </h2>
          </div>
          <div className="w-24 h-[2px] bg-gradient-to-r from-transparent via-gold to-transparent mx-auto" />
        </motion.div>

        {/* FAQ Accordion */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-50px' }}
        >
          <Accordion type="single" collapsible className="space-y-3">
            {faqItems.map((item, index) => (
              <motion.div key={index} variants={itemVariants}>
                <AccordionItem
                  value={`item-${index}`}
                  className="glass rounded-xl px-6 border-0 data-[state=open]:gold-glow transition-all duration-300 overflow-hidden group"
                >
                  <AccordionTrigger className="text-white hover:no-underline hover:text-gold-light transition-colors duration-300 py-5 text-base font-medium [&[data-state=open]>svg]:text-gold">
                    <span className="flex items-center gap-3 text-left">
                      <span className="w-7 h-7 rounded-full bg-gold/10 flex items-center justify-center text-gold text-xs font-bold shrink-0">
                        {index + 1}
                      </span>
                      {item.question}
                    </span>
                  </AccordionTrigger>
                  <AccordionContent className="text-gray-400 leading-relaxed pb-5 pl-10">
                    {item.answer}
                  </AccordionContent>
                </AccordionItem>
              </motion.div>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </section>
  )
}
