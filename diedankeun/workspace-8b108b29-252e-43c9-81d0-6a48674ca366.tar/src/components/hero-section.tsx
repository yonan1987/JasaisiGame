'use client';

import { motion } from 'framer-motion';
import { ChevronDown, MessageCircle, Phone } from 'lucide-react';
import Image from 'next/image';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15,
      delayChildren: 0.2,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] },
  },
};

export default function HeroSection() {
  const whatsappOrderUrl =
    'https://wa.me/6285163061987?text=Halo%20Mikayla%20Games%2C%20saya%20ingin%20isi%20game';

  const whatsappConsultUrl =
    'https://wa.me/6285163061987?text=Halo%20Mikayla%20Games%2C%20saya%20ingin%20konsultasi%20tentang%20layanan%20isi%20game';

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background image */}
      <Image
        src="/hero-bg.png"
        alt="MIKAYLA GAMES Hero Background"
        fill
        priority
        className="object-cover object-center"
        quality={90}
      />

      {/* Dark overlay gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/70 to-black/90" />

      {/* Subtle gold radial glow at center */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-[radial-gradient(circle,rgba(212,175,55,0.06)_0%,transparent_60%)]" />
      </div>

      {/* Content */}
      <motion.div
        className="relative z-10 flex flex-col items-center text-center px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Trust Badge */}
        <motion.div variants={itemVariants}>
          <div className="glass inline-flex items-center gap-2 px-4 py-2 sm:px-5 sm:py-2.5 rounded-full mb-6 sm:mb-8">
            <span className="text-gold text-xs sm:text-sm">★★★★★</span>
            <span className="text-white/90 text-xs sm:text-sm font-medium tracking-wide">
              Trusted Service Bandung
            </span>
          </div>
        </motion.div>

        {/* Main Headline */}
        <motion.h1
          variants={itemVariants}
          className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold leading-tight mb-4 sm:mb-6"
          style={{ fontFamily: "'Montserrat', sans-serif" }}
        >
          <span className="text-white">Upgrade Koleksi Game</span>
          <br />
          <span className="text-white">PlayStation Anda </span>
          <span className="gold-shimmer">Tanpa Ribet.</span>
        </motion.h1>

        {/* Subheadline */}
        <motion.p
          variants={itemVariants}
          className="text-white/70 text-sm sm:text-base md:text-lg max-w-2xl leading-relaxed mb-8 sm:mb-10"
        >
          Layanan isi game PS3 HEN, PS4 HEN, dan PS5 Jailbreak profesional di
          Bandung dengan kualitas premium, proses cepat, aman, dan bergaransi.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          variants={itemVariants}
          className="flex flex-col sm:flex-row items-center gap-3 sm:gap-4 w-full sm:w-auto"
        >
          {/* Primary CTA - Gold button */}
          <a
            href={whatsappOrderUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="group relative inline-flex items-center justify-center gap-2 w-full sm:w-auto px-7 py-3.5 sm:px-8 sm:py-4 rounded-xl font-semibold text-sm sm:text-base text-black bg-gradient-to-r from-gold-dark via-gold to-gold-light transition-all duration-300 hover:shadow-[0_0_30px_rgba(212,175,55,0.4)] hover:scale-[1.02] active:scale-[0.98]"
          >
            <MessageCircle className="w-5 h-5" />
            Isi Game Sekarang
            {/* Shimmer overlay on hover */}
            <span className="absolute inset-0 rounded-xl bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700" />
          </a>

          {/* Secondary CTA - Glass/Outline button */}
          <a
            href={whatsappConsultUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 w-full sm:w-auto px-7 py-3.5 sm:px-8 sm:py-4 rounded-xl font-semibold text-sm sm:text-base text-gold border border-gold/30 glass hover:border-gold/60 hover:bg-white/5 transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]"
          >
            <Phone className="w-5 h-5" />
            Konsultasi Gratis
          </a>
        </motion.div>
      </motion.div>

      {/* Scroll Down Indicator */}
      <motion.div
        className="absolute bottom-6 sm:bottom-10 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 0.8 }}
      >
        <span className="text-white/40 text-xs tracking-widest uppercase">
          Scroll
        </span>
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          <ChevronDown className="w-5 h-5 text-gold/60" />
        </motion.div>
      </motion.div>
    </section>
  );
}
