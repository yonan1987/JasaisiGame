'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Download, FileText, Loader2 } from 'lucide-react'
import { games } from '@/lib/game-data'

export default function PdfDownload() {
  const [generating, setGenerating] = useState(false)

  const generatePDF = async () => {
    setGenerating(true)
    try {
      const { jsPDF } = await import('jspdf')
      const doc = new jsPDF()

      const pageWidth = doc.internal.pageSize.getWidth()
      const margin = 20
      let y = 20

      // Helper: add gold-like color header bar
      const addHeaderBar = () => {
        doc.setFillColor(40, 35, 20)
        doc.rect(0, 0, pageWidth, 45, 'F')
        doc.setFillColor(212, 175, 55)
        doc.rect(0, 45, pageWidth, 2, 'F')
      }

      addHeaderBar()

      // Title
      doc.setTextColor(212, 175, 55)
      doc.setFontSize(28)
      doc.setFont('helvetica', 'bold')
      doc.text('MIKAYLA GAMES', pageWidth / 2, 22, { align: 'center' })

      doc.setFontSize(12)
      doc.setFont('helvetica', 'normal')
      doc.setTextColor(200, 200, 200)
      doc.text('Katalog Game & Layanan PlayStation', pageWidth / 2, 33, { align: 'center' })

      y = 55

      // Contact Info
      doc.setTextColor(212, 175, 55)
      doc.setFontSize(14)
      doc.setFont('helvetica', 'bold')
      doc.text('Informasi Kontak', margin, y)
      y += 8

      doc.setTextColor(60, 60, 60)
      doc.setFontSize(10)
      doc.setFont('helvetica', 'normal')
      doc.text('WhatsApp: +62 851-6306-1987', margin, y); y += 6
      doc.text('Alamat: Jatimulya V, Kelurahan Gumuruh, Kec. Batununggal, Kota Bandung 40275', margin, y); y += 6
      doc.text('Website: wa.me/6285163061987', margin, y); y += 12

      // Pricing Section
      doc.setTextColor(212, 175, 55)
      doc.setFontSize(14)
      doc.setFont('helvetica', 'bold')
      doc.text('Harga Layanan', margin, y)
      y += 8

      const prices = [
        ['PS3 HEN', 'Mulai Rp100.000'],
        ['PS4 HEN', 'Mulai Rp150.000'],
        ['PS5 Jailbreak', 'Mulai Rp250.000'],
        ['Update & Maintenance', 'Mulai Rp50.000'],
      ]

      doc.setFontSize(10)
      prices.forEach(([service, price]) => {
        doc.setFont('helvetica', 'bold')
        doc.setTextColor(60, 60, 60)
        doc.text(service, margin, y)
        doc.setFont('helvetica', 'normal')
        doc.setTextColor(212, 175, 55)
        doc.text(price, margin + 70, y)
        y += 6
      })

      y += 6
      doc.setFontSize(8)
      doc.setTextColor(120, 120, 120)
      doc.text('*Harga dapat berubah tergantung kapasitas penyimpanan dan jumlah game.', margin, y)
      y += 12

      // Game Catalog
      doc.setTextColor(212, 175, 55)
      doc.setFontSize(14)
      doc.setFont('helvetica', 'bold')
      doc.text('Katalog Game', margin, y)
      y += 8

      // Table header
      doc.setFillColor(40, 35, 20)
      doc.rect(margin, y - 4, pageWidth - margin * 2, 8, 'F')
      doc.setTextColor(212, 175, 55)
      doc.setFontSize(9)
      doc.setFont('helvetica', 'bold')
      doc.text('No.', margin + 2, y)
      doc.text('Nama Game', margin + 14, y)
      doc.text('Platform', margin + 110, y)
      doc.text('Genre', margin + 135, y)
      doc.text('Ukuran', margin + 165, y)
      y += 8

      // Game rows
      doc.setFont('helvetica', 'normal')
      doc.setFontSize(8)

      const ps3Games = games.filter(g => g.platform === 'PS3')
      const ps4Games = games.filter(g => g.platform === 'PS4')
      const ps5Games = games.filter(g => g.platform === 'PS5')

      const sections = [
        { title: 'PlayStation 5', games: ps5Games },
        { title: 'PlayStation 4', games: ps4Games },
        { title: 'PlayStation 3', games: ps3Games },
      ]

      let gameNum = 1

      sections.forEach(section => {
        if (y > 270) {
          doc.addPage()
          y = 20
        }

        doc.setTextColor(212, 175, 55)
        doc.setFont('helvetica', 'bold')
        doc.setFontSize(10)
        doc.text(section.title, margin, y)
        y += 6

        doc.setFont('helvetica', 'normal')
        doc.setFontSize(8)

        section.games.forEach(game => {
          if (y > 275) {
            doc.addPage()
            y = 20
          }

          doc.setTextColor(60, 60, 60)
          doc.text(String(gameNum) + '.', margin + 2, y)
          doc.text(game.name.substring(0, 40), margin + 14, y)
          doc.setTextColor(212, 175, 55)
          doc.text(game.platform, margin + 110, y)
          doc.setTextColor(80, 80, 80)
          doc.text(game.genre.substring(0, 20), margin + 135, y)
          doc.text(game.fileSize, margin + 165, y)
          y += 5
          gameNum++
        })

        y += 4
      })

      // Footer on last page
      if (y > 250) {
        doc.addPage()
        y = 20
      }

      y += 10
      doc.setFillColor(212, 175, 55)
      doc.rect(margin, y, pageWidth - margin * 2, 0.5, 'F')
      y += 8

      doc.setTextColor(212, 175, 55)
      doc.setFontSize(12)
      doc.setFont('helvetica', 'bold')
      doc.text('MIKAYLA GAMES', pageWidth / 2, y, { align: 'center' })
      y += 7

      doc.setTextColor(100, 100, 100)
      doc.setFontSize(9)
      doc.setFont('helvetica', 'normal')
      doc.text('Jasa Isi Game PlayStation Premium di Bandung', pageWidth / 2, y, { align: 'center' })
      y += 5
      doc.text('WhatsApp: +62 851-6306-1987 | wa.me/6285163061987', pageWidth / 2, y, { align: 'center' })
      y += 5
      doc.text('Jatimulya V, Kel. Gumuruh, Kec. Batununggal, Kota Bandung 40275', pageWidth / 2, y, { align: 'center' })

      doc.save('Katalog-Mikayla-Games.pdf')
    } catch (error) {
      console.error('PDF generation error:', error)
    } finally {
      setGenerating(false)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className="flex justify-center py-8"
    >
      <button
        onClick={generatePDF}
        disabled={generating}
        className="group relative inline-flex items-center gap-3 px-8 py-4 rounded-xl font-semibold text-sm sm:text-base transition-all duration-300 glass-strong border border-gold/30 hover:border-gold/60 text-gold hover:text-gold-light hover:gold-glow disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {generating ? (
          <Loader2 className="w-5 h-5 animate-spin" />
        ) : (
          <Download className="w-5 h-5 group-hover:animate-bounce" />
        )}
        {generating ? 'Menggenerate PDF...' : 'Download Katalog Game PDF'}
        <FileText className="w-4 h-4 opacity-50" />
      </button>
    </motion.div>
  )
}
