'use client'

import { useCallback, useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Star, Quote } from 'lucide-react'
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  type CarouselApi,
} from '@/components/ui/carousel'

interface Testimonial {
  text: string
  name: string
  location: string
}

const testimonials: Testimonial[] = [
  {
    text: 'Pelayanannya cepat dan ramah.',
    name: 'Andi',
    location: 'Bandung',
  },
  {
    text: 'Teknisi datang ke rumah, sangat membantu.',
    name: 'Budi',
    location: 'Buah Batu',
  },
  {
    text: 'Game lengkap, harga masuk akal.',
    name: 'Rina',
    location: 'Kiaracondong',
  },
]

export default function RatingSection() {
  const [api, setApi] = useState<CarouselApi>()

  const autoScroll = useCallback(() => {
    if (!api) return
    api.scrollNext()
  }, [api])

  useEffect(() => {
    if (!api) return
    const interval = setInterval(autoScroll, 5000)
    return () => clearInterval(interval)
  }, [api, autoScroll])

  return (
    <section className="relative py-20 md:py-28 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/3 right-0 w-80 h-80 bg-[#D4AF37]/5 rounded-full blur-[100px]" />
        <div className="absolute bottom-1/4 left-0 w-64 h-64 bg-[#D4AF37]/3 rounded-full blur-[100px]" />
      </div>

      <div className="relative max-w-5xl mx-auto">
        {/* Rating Display */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.7, ease: 'easeOut' }}
          className="text-center mb-14 md:mb-20"
        >
          {/* Large Rating Number */}
          <div className="mb-4">
            <span className="text-6xl sm:text-7xl md:text-8xl font-bold font-heading text-[#D4AF37] gold-glow-text">
              4.9
            </span>
            <span className="text-2xl sm:text-3xl md:text-4xl font-heading text-gray-500 ml-2">
              / 5.0
            </span>
          </div>

          {/* Five Gold Stars */}
          <div className="flex items-center justify-center gap-2 mb-5">
            {Array.from({ length: 5 }).map((_, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0, rotate: -30 }}
                whileInView={{ opacity: 1, scale: 1, rotate: 0 }}
                viewport={{ once: true }}
                transition={{
                  duration: 0.4,
                  delay: 0.3 + i * 0.1,
                  type: 'spring',
                  stiffness: 200,
                }}
              >
                <Star className="w-8 h-8 sm:w-10 sm:h-10 text-[#D4AF37] fill-[#D4AF37]" />
              </motion.div>
            ))}
          </div>

          {/* Subtitle */}
          <p className="text-base sm:text-lg text-gray-400">
            Berdasarkan <span className="text-[#D4AF37] font-semibold">500+</span> pelanggan puas
          </p>

          {/* Decorative divider */}
          <motion.div
            initial={{ width: 0 }}
            whileInView={{ width: 96 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.6, ease: 'easeOut' }}
            className="h-0.5 bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent mx-auto mt-6"
          />
        </motion.div>

        {/* Testimonial Carousel */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.7, delay: 0.2, ease: 'easeOut' }}
        >
          <Carousel
            setApi={setApi}
            opts={{
              loop: true,
              align: 'center',
            }}
            className="w-full max-w-2xl mx-auto"
          >
            <CarouselContent>
              {testimonials.map((testimonial) => (
                <CarouselItem key={testimonial.name}>
                  <TestimonialCard testimonial={testimonial} />
                </CarouselItem>
              ))}
            </CarouselContent>
          </Carousel>

          {/* Dots indicator */}
          <CarouselDots api={api} total={testimonials.length} />
        </motion.div>
      </div>
    </section>
  )
}

function TestimonialCard({ testimonial }: { testimonial: Testimonial }) {
  return (
    <div className="glass-strong rounded-2xl p-8 md:p-10 text-center relative overflow-hidden">
      {/* Subtle gold top accent */}
      <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#D4AF37]/40 to-transparent" />

      {/* Gold Quote Mark */}
      <div className="flex justify-center mb-5">
        <Quote className="w-10 h-10 text-[#D4AF37]/40 rotate-180" />
      </div>

      {/* Testimonial Text */}
      <p className="text-lg md:text-xl text-gray-200 leading-relaxed mb-6 italic">
        &ldquo;{testimonial.text}&rdquo;
      </p>

      {/* Name and Location */}
      <div>
        <span className="text-[#D4AF37] font-semibold font-heading text-base">
          {testimonial.name}
        </span>
        <span className="text-gray-500 mx-2">–</span>
        <span className="text-gray-400 text-sm">{testimonial.location}</span>
      </div>
    </div>
  )
}

function CarouselDots({
  api,
  total,
}: {
  api: CarouselApi | undefined
  total: number
}) {
  const [current, setCurrent] = useState(0)

  useEffect(() => {
    if (!api) return

    const onSelect = () => {
      setCurrent(api.selectedScrollSnap())
    }

    onSelect()
    api.on('select', onSelect)
    return () => {
      api.off('select', onSelect)
    }
  }, [api])

  return (
    <div className="flex items-center justify-center gap-2 mt-8">
      {Array.from({ length: total }).map((_, i) => (
        <button
          key={i}
          onClick={() => api?.scrollTo(i)}
          className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
            i === current
              ? 'bg-[#D4AF37] w-8 shadow-[0_0_8px_rgba(212,175,55,0.5)]'
              : 'bg-gray-600 hover:bg-gray-500'
          }`}
          aria-label={`Go to testimonial ${i + 1}`}
        />
      ))}
    </div>
  )
}
