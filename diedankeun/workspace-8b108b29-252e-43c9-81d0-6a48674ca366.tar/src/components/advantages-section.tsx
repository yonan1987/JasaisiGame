'use client'

import { motion } from 'framer-motion'
import { Zap, Shield, Gamepad2, Home, MessageCircle, Star } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

interface Advantage {
  icon: LucideIcon
  title: string
  description: string
}

const advantages: Advantage[] = [
  {
    icon: Zap,
    title: 'Proses Cepat',
    description: 'Ratusan game siap instal tanpa antre lama.',
  },
  {
    icon: Shield,
    title: 'Aman dan Berpengalaman',
    description: 'Dikerjakan dengan prosedur yang aman.',
  },
  {
    icon: Gamepad2,
    title: 'Koleksi Game Lengkap',
    description: 'Ribuan pilihan game populer berbagai genre.',
  },
  {
    icon: Home,
    title: 'Bisa Panggilan ke Rumah',
    description: 'Teknisi datang ke lokasi Anda.',
  },
  {
    icon: MessageCircle,
    title: 'Konsultasi Gratis',
    description: 'Bingung firmware atau kompatibilitas? Kami bantu.',
  },
  {
    icon: Star,
    title: 'Pelanggan Puas',
    description: 'Didukung banyak pelanggan loyal.',
  },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15,
      delayChildren: 0.2,
    },
  },
}

const cardVariants = {
  hidden: {
    opacity: 0,
    y: 40,
    scale: 0.95,
  },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      duration: 0.6,
      ease: [0.25, 0.46, 0.45, 0.94],
    },
  },
}

export default function AdvantagesSection() {
  return (
    <section className="relative py-20 md:py-28 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Subtle background decoration */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#D4AF37]/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#D4AF37]/3 rounded-full blur-[120px]" />
      </div>

      <div className="relative max-w-7xl mx-auto">
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.7, ease: 'easeOut' }}
          className="text-center mb-14 md:mb-20"
        >
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold font-heading leading-tight">
            Mengapa Memilih{' '}
            <span className="gold-shimmer">Mikayla Games</span>?
          </h2>
          <motion.div
            initial={{ width: 0 }}
            whileInView={{ width: 96 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.4, ease: 'easeOut' }}
            className="h-0.5 bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent mx-auto mt-6"
          />
        </motion.div>

        {/* Advantages Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-60px' }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
        >
          {advantages.map((advantage) => (
            <AdvantageCard key={advantage.title} advantage={advantage} />
          ))}
        </motion.div>
      </div>
    </section>
  )
}

function AdvantageCard({ advantage }: { advantage: Advantage }) {
  const Icon = advantage.icon

  return (
    <motion.div
      variants={cardVariants}
      whileHover={{
        y: -6,
        transition: { duration: 0.3, ease: 'easeOut' },
      }}
      className="group relative glass rounded-2xl p-6 md:p-8 cursor-default transition-shadow duration-500 hover:gold-glow"
    >
      {/* Gold top border accent */}
      <div className="absolute top-0 left-0 right-0 h-[2px] rounded-t-2xl bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent opacity-60 group-hover:opacity-100 transition-opacity duration-500" />

      {/* Icon */}
      <div className="mb-5 inline-flex items-center justify-center w-14 h-14 rounded-xl bg-[#D4AF37]/10 border border-[#D4AF37]/20 group-hover:bg-[#D4AF37]/20 transition-colors duration-500">
        <Icon className="w-7 h-7 text-[#D4AF37] group-hover:text-[#F0D060] transition-colors duration-300" />
      </div>

      {/* Title */}
      <h3 className="text-lg md:text-xl font-semibold font-heading text-white mb-2 group-hover:text-[#F0D060] transition-colors duration-300">
        {advantage.title}
      </h3>

      {/* Description */}
      <p className="text-sm md:text-base text-gray-400 leading-relaxed">
        {advantage.description}
      </p>
    </motion.div>
  )
}
