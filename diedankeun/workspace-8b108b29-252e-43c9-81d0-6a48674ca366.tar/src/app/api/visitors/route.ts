import { NextResponse } from "next/server";

// Simple in-memory visitor counter
let visitorCount = 12458;
let lastResetDate = new Date().toDateString();

export async function GET() {
  const today = new Date().toDateString();
  
  // Reset counter daily
  if (today !== lastResetDate) {
    visitorCount = Math.floor(Math.random() * 5000) + 8000;
    lastResetDate = today;
  }
  
  // Increment randomly (simulating real visitors)
  const increment = Math.floor(Math.random() * 3) + 1;
  visitorCount += increment;
  
  return NextResponse.json({ count: visitorCount });
}
