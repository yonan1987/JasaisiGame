import { NextResponse } from "next/server";
import { games } from "@/lib/game-data";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const platform = searchParams.get("platform");
  const search = searchParams.get("search");

  let filtered = [...games];

  if (platform && platform !== "ALL") {
    filtered = filtered.filter((g) => g.platform === platform);
  }

  if (search) {
    const q = search.toLowerCase();
    filtered = filtered.filter(
      (g) =>
        g.name.toLowerCase().includes(q) ||
        g.genre.toLowerCase().includes(q)
    );
  }

  return NextResponse.json({ games: filtered, total: filtered.length });
}
