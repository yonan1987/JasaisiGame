'use client'

import { TooltipProvider } from '@/components/ui/tooltip'
import LoadingScreen from '@/components/loading-screen'
import HeroSection from '@/components/hero-section'
import AdvantagesSection from '@/components/advantages-section'
import RatingSection from '@/components/rating-section'
import PricingSection from '@/components/pricing-section'
import CostEstimator from '@/components/cost-estimator'
import GameCatalog from '@/components/game-catalog'
import PdfDownload from '@/components/pdf-download'
import VisitorCounter from '@/components/visitor-counter'
import FaqSection from '@/components/faq-section'
import FooterSection from '@/components/footer-section'
import WhatsAppButton from '@/components/whatsapp-button'

export default function Home() {
  return (
    <TooltipProvider>
      <div className="min-h-screen flex flex-col bg-background">
        {/* Loading Screen */}
        <LoadingScreen />

        {/* Main Content */}
        <main className="flex-1">
          {/* Hero Section */}
          <HeroSection />

          {/* Advantages Section */}
          <AdvantagesSection />

          {/* Rating Section */}
          <RatingSection />

          {/* Pricing Section */}
          <PricingSection />

          {/* Cost Estimator */}
          <CostEstimator />

          {/* Visitor Counter */}
          <VisitorCounter />

          {/* Game Catalog */}
          <GameCatalog />

          {/* PDF Download */}
          <PdfDownload />

          {/* FAQ Section */}
          <FaqSection />
        </main>

        {/* Footer */}
        <FooterSection />

        {/* Floating WhatsApp Button */}
        <WhatsAppButton />
      </div>
    </TooltipProvider>
  )
}
