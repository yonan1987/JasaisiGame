import type { Metadata } from "next";
import { Poppins, Montserrat } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700", "800", "900"],
  variable: "--font-poppins",
  display: "swap",
});

const montserrat = Montserrat({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700", "800", "900"],
  variable: "--font-montserrat",
  display: "swap",
});

export const metadata: Metadata = {
  title: "MIKAYLA GAMES - Jasa Isi Game PlayStation Premium Bandung",
  description:
    "Layanan isi game PS3 HEN, PS4 HEN, dan PS5 Jailbreak profesional di Bandung. Kualitas premium, proses cepat, aman, dan bergaransi. Panggilan ke rumah tersedia.",
  keywords: [
    "isi game ps3",
    "isi game ps4",
    "ps5 jailbreak",
    "HEN PS3",
    "HEN PS4",
    "jasa isi game bandung",
    "mikayla games",
    "game playstation bandung",
    "install game ps4",
    "install game ps5",
  ],
  authors: [{ name: "MIKAYLA GAMES" }],
  icons: {
    icon: "/logo-mikayla.png",
  },
  openGraph: {
    title: "MIKAYLA GAMES - Jasa Isi Game PlayStation Premium Bandung",
    description:
      "Layanan isi game PS3 HEN, PS4 HEN, dan PS5 Jailbreak profesional di Bandung dengan kualitas premium.",
    type: "website",
    locale: "id_ID",
    siteName: "MIKAYLA GAMES",
  },
  twitter: {
    card: "summary_large_image",
    title: "MIKAYLA GAMES - Jasa Isi Game PlayStation Premium",
    description:
      "Layanan isi game PS3 HEN, PS4 HEN, dan PS5 Jailbreak profesional di Bandung.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" className={`dark ${poppins.variable} ${montserrat.variable}`} suppressHydrationWarning>
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "LocalBusiness",
              name: "MIKAYLA GAMES",
              description:
                "Jasa isi game PlayStation PS3 HEN, PS4 HEN, dan PS5 Jailbreak profesional di Bandung",
              url: "https://mikaylagames.com",
              telephone: "+6285163061987",
              address: {
                "@type": "PostalAddress",
                streetAddress: "Jatimulya V",
                addressLocality: "Bandung",
                addressRegion: "Jawa Barat",
                postalCode: "40275",
                addressCountry: "ID",
              },
              geo: {
                "@type": "GeoCoordinates",
                latitude: -6.9175,
                longitude: 107.6191,
              },
              openingHours: "Mo-Su 09:00-21:00",
              priceRange: "Rp50.000 - Rp250.000",
              aggregateRating: {
                "@type": "AggregateRating",
                ratingValue: "4.9",
                reviewCount: "500",
              },
              sameAs: [
                "https://wa.me/6285163061987",
              ],
            }),
          }}
        />
      </head>
      <body className="antialiased bg-background text-foreground">
        {children}
        <Toaster />
      </body>
    </html>
  );
}
