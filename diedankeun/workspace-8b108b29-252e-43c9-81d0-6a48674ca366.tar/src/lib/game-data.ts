export interface Game {
  id: number;
  name: string;
  genre: string;
  platform: "PS3" | "PS4" | "PS5";
  fileSize: string;
  status: "Tersedia";
  cover: string;
}

export const games: Game[] = [
  { id: 1, name: "God of War Ragnarök", genre: "Action-Adventure", platform: "PS5", fileSize: "90 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=400&h=600&fit=crop" },
  { id: 2, name: "Spider-Man 2", genre: "Action-Adventure", platform: "PS5", fileSize: "86 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=400&h=600&fit=crop" },
  { id: 3, name: "Horizon Forbidden West", genre: "Action RPG", platform: "PS5", fileSize: "96 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=400&h=600&fit=crop" },
  { id: 4, name: "Demon's Souls", genre: "Action RPG", platform: "PS5", fileSize: "66 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1535223289827-42f1e9919769?w=400&h=600&fit=crop" },
  { id: 5, name: "Ratchet & Clank: Rift Apart", genre: "Platformer", platform: "PS5", fileSize: "42 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1551103782-8ab07afd45c1?w=400&h=600&fit=crop" },
  { id: 6, name: "Returnal", genre: "Roguelike", platform: "PS5", fileSize: "56 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=400&h=600&fit=crop" },
  { id: 7, name: "Final Fantasy XVI", genre: "Action RPG", platform: "PS5", fileSize: "91 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1559363367-ee2abc8b3880?w=400&h=600&fit=crop" },
  { id: 8, name: "Baldur's Gate 3", genre: "RPG", platform: "PS5", fileSize: "120 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1556438064-2d7646166914?w=400&h=600&fit=crop" },
  { id: 9, name: "Resident Evil 4 Remake", genre: "Horror", platform: "PS5", fileSize: "67 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1509281373149-e957c6296406?w=400&h=600&fit=crop" },
  { id: 10, name: "Star Wars Jedi: Survivor", genre: "Action-Adventure", platform: "PS5", fileSize: "148 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1535016120720-40c646be5580?w=400&h=600&fit=crop" },
  { id: 11, name: "The Last of Us Part I", genre: "Action-Adventure", platform: "PS5", fileSize: "79 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?w=400&h=600&fit=crop" },
  { id: 12, name: "Gran Turismo 7", genre: "Racing", platform: "PS5", fileSize: "110 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1547394765-185e1e68f34e?w=400&h=600&fit=crop" },
  { id: 13, name: "Ghost of Tsushima: Director's Cut", genre: "Action-Adventure", platform: "PS5", fileSize: "68 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1528164344705-47542687000d?w=400&h=600&fit=crop" },
  { id: 14, name: "Uncharted: Legacy of Thieves", genre: "Action-Adventure", platform: "PS5", fileSize: "70 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?w=400&h=600&fit=crop" },
  { id: 15, name: "Death Stranding: Director's Cut", genre: "Action", platform: "PS5", fileSize: "80 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=400&h=600&fit=crop" },
  { id: 16, name: "Sackboy: A Big Adventure", genre: "Platformer", platform: "PS5", fileSize: "35 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1551103782-8ab07afd45c1?w=400&h=600&fit=crop" },
  { id: 17, name: "Destruction AllStars", genre: "Racing", platform: "PS5", fileSize: "37 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1547394765-185e1e68f34e?w=400&h=600&fit=crop" },
  { id: 18, name: "Marvel's Spider-Man: Miles Morales", genre: "Action-Adventure", platform: "PS5", fileSize: "53 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=400&h=600&fit=crop" },
  { id: 19, name: "God of War (2018)", genre: "Action-Adventure", platform: "PS4", fileSize: "45 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=400&h=600&fit=crop" },
  { id: 20, name: "Marvel's Spider-Man", genre: "Action-Adventure", platform: "PS4", fileSize: "47 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=400&h=600&fit=crop" },
  { id: 21, name: "The Last of Us Part II", genre: "Action-Adventure", platform: "PS4", fileSize: "79 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?w=400&h=600&fit=crop" },
  { id: 22, name: "Horizon Zero Dawn", genre: "Action RPG", platform: "PS4", fileSize: "50 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=400&h=600&fit=crop" },
  { id: 23, name: "Red Dead Redemption 2", genre: "Action-Adventure", platform: "PS4", fileSize: "105 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1535223289827-42f1e9919769?w=400&h=600&fit=crop" },
  { id: 24, name: "Ghost of Tsushima", genre: "Action-Adventure", platform: "PS4", fileSize: "50 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1528164344705-47542687000d?w=400&h=600&fit=crop" },
  { id: 25, name: "Persona 5 Royal", genre: "JRPG", platform: "PS4", fileSize: "38 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1559363367-ee2abc8b3880?w=400&h=600&fit=crop" },
  { id: 26, name: "Bloodborne", genre: "Action RPG", platform: "PS4", fileSize: "30 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1535223289827-42f1e9919769?w=400&h=600&fit=crop" },
  { id: 27, name: "Uncharted 4: A Thief's End", genre: "Action-Adventure", platform: "PS4", fileSize: "63 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?w=400&h=600&fit=crop" },
  { id: 28, name: "Detroit: Become Human", genre: "Interactive Drama", platform: "PS4", fileSize: "42 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1556438064-2d7646166914?w=400&h=600&fit=crop" },
  { id: 29, name: "Days Gone", genre: "Action-Adventure", platform: "PS4", fileSize: "60 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1509281373149-e957c6296406?w=400&h=600&fit=crop" },
  { id: 30, name: "Death Stranding", genre: "Action", platform: "PS4", fileSize: "55 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=400&h=600&fit=crop" },
  { id: 31, name: "Final Fantasy VII Remake", genre: "RPG", platform: "PS4", fileSize: "86 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1559363367-ee2abc8b3880?w=400&h=600&fit=crop" },
  { id: 32, name: "Resident Evil Village", genre: "Horror", platform: "PS4", fileSize: "35 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1509281373149-e957c6296406?w=400&h=600&fit=crop" },
  { id: 33, name: "FIFA 24", genre: "Sports", platform: "PS4", fileSize: "50 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=400&h=600&fit=crop" },
  { id: 34, name: "Call of Duty: Modern Warfare III", genre: "FPS", platform: "PS4", fileSize: "120 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1535016120720-40c646be5580?w=400&h=600&fit=crop" },
  { id: 35, name: "Grand Theft Auto V", genre: "Action-Adventure", platform: "PS4", fileSize: "85 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1535223289827-42f1e9919769?w=400&h=600&fit=crop" },
  { id: 36, name: "The Witcher 3: Wild Hunt", genre: "RPG", platform: "PS4", fileSize: "50 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1556438064-2d7646166914?w=400&h=600&fit=crop" },
  { id: 37, name: "Sekiro: Shadows Die Twice", genre: "Action-Adventure", platform: "PS4", fileSize: "25 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1528164344705-47542687000d?w=400&h=600&fit=crop" },
  { id: 38, name: "Elden Ring", genre: "Action RPG", platform: "PS4", fileSize: "50 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1535223289827-42f1e9919769?w=400&h=600&fit=crop" },
  { id: 39, name: "The Last of Us Remastered", genre: "Action-Adventure", platform: "PS4", fileSize: "32 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?w=400&h=600&fit=crop" },
  { id: 40, name: "Metal Gear Solid V", genre: "Stealth-Action", platform: "PS4", fileSize: "28 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1535016120720-40c646be5580?w=400&h=600&fit=crop" },
  { id: 41, name: "The Last of Us", genre: "Action-Adventure", platform: "PS3", fileSize: "24 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?w=400&h=600&fit=crop" },
  { id: 42, name: "Uncharted 3: Drake's Deception", genre: "Action-Adventure", platform: "PS3", fileSize: "20 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?w=400&h=600&fit=crop" },
  { id: 43, name: "God of War III", genre: "Action", platform: "PS3", fileSize: "35 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=400&h=600&fit=crop" },
  { id: 44, name: "Gran Turismo 6", genre: "Racing", platform: "PS3", fileSize: "15 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1547394765-185e1e68f34e?w=400&h=600&fit=crop" },
  { id: 45, name: "Metal Gear Solid 4", genre: "Stealth-Action", platform: "PS3", fileSize: "30 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1535016120720-40c646be5580?w=400&h=600&fit=crop" },
  { id: 46, name: "Red Dead Redemption", genre: "Action-Adventure", platform: "PS3", fileSize: "8 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1535223289827-42f1e9919769?w=400&h=600&fit=crop" },
  { id: 47, name: "GTA IV", genre: "Action-Adventure", platform: "PS3", fileSize: "18 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1535223289827-42f1e9919769?w=400&h=600&fit=crop" },
  { id: 48, name: "FIFA 19", genre: "Sports", platform: "PS3", fileSize: "8 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=400&h=600&fit=crop" },
  { id: 49, name: "Call of Duty: Black Ops II", genre: "FPS", platform: "PS3", fileSize: "18 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1535016120720-40c646be5580?w=400&h=600&fit=crop" },
  { id: 50, name: "Batman: Arkham City", genre: "Action-Adventure", platform: "PS3", fileSize: "15 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=400&h=600&fit=crop" },
  { id: 51, name: "Dark Souls", genre: "Action RPG", platform: "PS3", fileSize: "7 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1535223289827-42f1e9919769?w=400&h=600&fit=crop" },
  { id: 52, name: "Ni no Kuni", genre: "JRPG", platform: "PS3", fileSize: "12 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1559363367-ee2abc8b3880?w=400&h=600&fit=crop" },
  { id: 53, name: "LittleBigPlanet 2", genre: "Platformer", platform: "PS3", fileSize: "6 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1551103782-8ab07afd45c1?w=400&h=600&fit=crop" },
  { id: 54, name: "Heavy Rain", genre: "Interactive Drama", platform: "PS3", fileSize: "22 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1556438064-2d7646166914?w=400&h=600&fit=crop" },
  { id: 55, name: "Infamous 2", genre: "Action-Adventure", platform: "PS3", fileSize: "12 GB", status: "Tersedia", cover: "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=400&h=600&fit=crop" },
];

export const platformFilters = ["PS3", "PS4", "PS5"] as const;
export type PlatformFilter = (typeof platformFilters)[number];
